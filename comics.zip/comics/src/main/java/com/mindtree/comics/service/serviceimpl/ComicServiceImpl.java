package com.mindtree.comics.service.serviceimpl;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.comics.dto.ComicDto;
import com.mindtree.comics.dto.SuperHeroDto;
import com.mindtree.comics.entity.Comic;
import com.mindtree.comics.entity.Power;
import com.mindtree.comics.entity.SuperHero;
import com.mindtree.comics.exception.serviceexception.ComicServiceException;
import com.mindtree.comics.exception.serviceexception.PowerNotFoundException;
import com.mindtree.comics.repository.ComicRepository;
import com.mindtree.comics.repository.PowerRepository;
import com.mindtree.comics.repository.SuperHeroRepository;
import com.mindtree.comics.service.ComicService;

@Service
public class ComicServiceImpl implements ComicService {

	@Autowired
	ComicRepository comicRepository;
	@Autowired
	PowerRepository powerRepository;
	@Autowired
	SuperHeroRepository superHeroRepository;

	ModelMapper modelMapper = new ModelMapper();

	@Override
	public String insertComicWithOthers(ComicDto comicDto) {

		Set<Power>powers = new HashSet<>();
//		SuperHero superHero = modelMapper.map(superHeroDto, SuperHero.class);
//		superHeroDto.getPowers().forEach(powerDto->{
//			Power power = modelMapper.map(powerDto, Power.class);
//			power.setSuperHero(superHero);
//			powers.add(power);		
//		});
		//superHero.setPowers(powers);
		//superHeroRepository.save(superHero);
		Comic comic = modelMapper.map(comicDto, Comic.class);
		//comicRepository.save(comic);
		Set<SuperHero> superHeroes = comic.getSuperHeroes();
		//comicRepository.save(comic);
		//for(SuperHero sh:superHeroes )
		
		superHeroes.forEach(i -> {
			i.setComic(comic);
			i.getPowers().forEach(j -> {
				j.setSuperHero(i);
				//power.setSuperHero(superHero);
			////	powers.add(j);
				//superHeroRepository.save(i);
				powerRepository.save(j);
			});
			//i.setPowers(powers);
			//superHeroRepository.save(i);
		});
		
		comicRepository.save(comic);

		return "inserted";
	}

	@Override
	public Set<SuperHeroDto> getAllSuperHeroesByGivenPowerDescription() {

		//java.util.List<Power> powers = powerRepository.findAll();
		Set<SuperHeroDto> superHeroDtos = new HashSet<SuperHeroDto>();

		Set<Power>powers1 = powerRepository.findAll().stream().filter(power-> power.getPowerName().equalsIgnoreCase("flying")
					|| power.getPowerName().equalsIgnoreCase("invisisbility")).collect(Collectors.toSet());
		
		
		powers1.forEach(power -> {
				SuperHero superHero = power.getSuperHero();
				SuperHeroDto superHeroDto = modelMapper.map(superHero, SuperHeroDto.class);
				superHeroDtos.add(superHeroDto);
			
		});

		return superHeroDtos;
	}

	@Override
	public int getCombinedDamageBySuperHeroId(int superHeroId) throws ComicServiceException {

		SuperHero superHero;

		superHero = superHeroRepository.findById(superHeroId)
				.orElseThrow(() -> new PowerNotFoundException("No such power Found"));

		int total = superHero.getPowers().stream().reduce(0, (result, power) -> result + power.getPowerDamage(),
				Integer::sum);
//		for (Power power : superHero.getPowers()) {
//			total = total + power.getPowerDamage();
//
//		}

		return total;
	}

}
